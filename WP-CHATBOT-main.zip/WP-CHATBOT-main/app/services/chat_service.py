import json
import re
from typing import Any, Dict, Optional

from ..models import ChatRequest, ChatResponse, UserCreate, UserUpdate
from . import user_service
from .. import db
from ..chatbot import llm, conversation

SYSTEM_PROMPT = (
    "You are an AI admin assistant for user management.\n"
    "The user may write in English, Roman Urdu/Hindi, or a mix of both.\n"
    "Respond ONLY with a valid JSON object (no markdown formatting, no extra text).\n"
    "JSON Schema:\n"
    "{\n"
    '  "intent": "CREATE" | "READ" | "UPDATE" | "DELETE" | "SEARCH" | "COUNT" | "HELP" | "UNKNOWN",\n'
    '  "fields": {\n'
    '     "name": string|null,\n'
    '     "email": string|null,\n'
    '     "phone": string|null,\n'
    '     "address": string|null,\n'
    '     "user_id": int|null,\n'
    '     "target_identifier": string|null,\n'
    '     "target_name": string|null,\n'
    '     "update_field": string|null,\n'
    '     "update_value": string|null,\n'
    '     "confirmation": "yes" | "no" | null\n'
    '  }\n'
    "}\n\n"
    "Rules:\n"
    "1. READ Intent: Recognize 'get user 1', 'get afaq', 'show me afaq', 'ali ka record dekhao', 'afaq ki details dikhao', 'who is afaq', 'afaq kaun hai'. Extract user_id or target_identifier (name/email).\n"
    "2. CREATE Intent: Extract name, email, phone, address if present. Address is ALWAYS required for standard creation unless the user provided email+phone upfront without a name (email-only quick create).\n"
    "3. UPDATE Intent: Recognize 'update samantha\'s address to Cordoba' or 'update john.smith@xyz.com'. Extract target_identifier (email or name), update_field, and update_value.\n"
    "4. DELETE Intent: Recognize 'remove the user john.smith@xyz.com' or 'delete mohsin'. Extract target_identifier (email or name). If user confirms ('yes'/'haan'), set confirmation='yes'.\n"
    "5. Identifier Lookup: target_identifier can be an ID, email (e.g. 'john.smith@xyz.com') OR a name (e.g. 'afaq', 'ali')."
)

def _parse_llm_response(text: str) -> Dict[str, Any]:
    try:
        cleaned = text.strip()
        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        if cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        return json.loads(cleaned.strip())
    except Exception as e:
        raise ValueError(f"LLM returned invalid JSON: {e}. Raw output: {text}")

def _is_roman_urdu(query: str) -> bool:
    q = query.lower()
    urdu_words = ["ko", "kr", "kar", "karo", "banao", "bana", "do", "dein", "chahiye", "naam", "ka", "nayi", "naya", "kijiye", "batao", "bataein", "main", "zaroorat", "haan", "hatao", "pata", "address", "dekhao", "dikhao", "kaun", "record"]
    return any(re.search(r'\b' + re.escape(w) + r'\b', q) for w in urdu_words)

def _find_user_by_identifier(user_id: Optional[int], identifier: Optional[str], name: Optional[str]) -> Optional[Dict[str, Any]]:
    """Find user by ID, exact email match, or fuzzy name match."""
    if user_id:
        u = db.get_user_by_id(user_id)
        if u: return u

    target = identifier or name
    if not target:
        return None

    if isinstance(target, int) or (isinstance(target, str) and target.isdigit()):
        u = db.get_user_by_id(int(target))
        if u: return u

    if "@" in target:
        email_clean = target.strip().lower()
        u = db.get_user_by_email(email_clean)
        if u: return u
        email_m = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', target)
        if email_m:
            u = db.get_user_by_email(email_m.group(0).lower())
            if u: return u

    return db.find_user_by_name_fuzzy(target)

def _rule_based_intent_parser(user_query: str, current_collected: Dict[str, Any], current_intent: Optional[str]) -> Dict[str, Any]:
    q = user_query.strip().lower()
    email_m = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', user_query)
    phone_m = re.search(r'\+?[0-9]{7,15}', user_query)

    # Handle confirmation for pending DELETE
    if current_intent == "DELETE":
        if any(w in q for w in ["yes", "yep", "yeah", "haan", "ha", "confirm", "ok", "sure"]):
            return {"intent": "DELETE", "fields": {"confirmation": "yes"}}

    # Handle follow-up for pending UPDATE
    if current_intent == "UPDATE":
        target_field = current_collected.get("update_field")
        if not target_field:
            for field in ["email", "phone", "address", "name"]:
                if field in q:
                    return {"intent": "UPDATE", "fields": {"update_field": field}}
        else:
            new_val = None
            if email_m: new_val = email_m.group(0)
            elif phone_m: new_val = phone_m.group(0)
            else: new_val = user_query.strip()
            return {"intent": "UPDATE", "fields": {"update_value": new_val}}

    # Handle follow-up for pending CREATE
    if current_intent == "CREATE":
        fields = {}
        if email_m: fields["email"] = email_m.group(0)
        if phone_m: fields["phone"] = phone_m.group(0)
        if not current_collected.get("address") and not email_m and not phone_m:
            fields["address"] = user_query.strip()
        if fields:
            return {"intent": "CREATE", "fields": fields}

    # READ INTENT RECOGNITION
    if any(k in q for k in ["get", "show", "read", "view", "dekhao", "dikhao", "dikhayein", "who is", "kaun hai", "record"]):
        user_id_m = re.search(r'(?:user\s+)?(\d+)', q)
        if user_id_m:
            return {"intent": "READ", "fields": {"user_id": int(user_id_m.group(1))}}

        target_id = email_m.group(0) if email_m else None
        if not target_id:
            cleaned_target = re.sub(
                r'^(get|show\s+me|show|read|view|who\s+is|dikhayein|dikhao)\s+(user\s+)?',
                '',
                user_query,
                flags=re.IGNORECASE
            ).strip()
            cleaned_target = re.sub(
                r'(\'s\s+details|\s+details|\s+ka\s+record\s+dekhao|\s+ki\s+details\s+dikhao|\s+kaun\s+hai|\s+record|\s+dekhao|\s+dikhao|\s+ka|\s+ki)$',
                '',
                cleaned_target,
                flags=re.IGNORECASE
            ).strip()
            if cleaned_target and cleaned_target.lower() not in ["me", "user", "users"]:
                target_id = cleaned_target

        if target_id:
            return {"intent": "READ", "fields": {"target_identifier": target_id}}

    # Standard UPDATE intent recognition
    if any(k in q for k in ["update", "change", "badlo", "modify"]):
        user_id_m = re.search(r'user\s+(\d+)', q)
        uid = int(user_id_m.group(1)) if user_id_m else None
        
        target_id = email_m.group(0) if email_m else None
        if not target_id:
            poss_m = re.search(r'update\s+([A-Za-z0-9_\.-]+)(?:\'s)?\s+(?:address|email|phone)', user_query, re.IGNORECASE)
            if poss_m:
                target_id = poss_m.group(1)
            else:
                words = [w for w in re.split(r'\s+', user_query) if w.lower() not in ["update", "change", "badlo", "modify", "user", "ka", "ko", "ki", "email", "phone", "address", "to", "set"]]
                target_id = " ".join(words).strip() if words else None

        field_target = None
        for f in ["email", "phone", "address", "name"]:
            if f in q:
                field_target = f
                break

        val_target = None
        to_m = re.search(r'\bto\s+([A-Za-z0-9\s,]+)$', user_query, re.IGNORECASE)
        if to_m:
            val_target = to_m.group(1).strip()
        elif email_m: val_target = email_m.group(0)
        elif phone_m: val_target = phone_m.group(0)

        fields = {}
        if uid: fields["user_id"] = uid
        if target_id: fields["target_identifier"] = target_id
        if field_target: fields["update_field"] = field_target
        if val_target: fields["update_value"] = val_target

        return {"intent": "UPDATE", "fields": fields}

    # Standard DELETE intent recognition
    if any(k in q for k in ["delete", "remove", "hatao", "khatam"]):
        user_id_m = re.search(r'user\s+(\d+)', q)
        uid = int(user_id_m.group(1)) if user_id_m else None
        
        target_id = email_m.group(0) if email_m else None
        if not target_id:
            words = [w for w in re.split(r'\s+', user_query) if w.lower() not in ["delete", "remove", "hatao", "khatam", "user", "the", "ko", "kr", "do", "karo"]]
            target_id = " ".join(words).strip() if words else None

        fields = {}
        if uid: fields["user_id"] = uid
        if target_id: fields["target_identifier"] = target_id
        return {"intent": "DELETE", "fields": fields}

    # Standard CREATE intent recognition
    if any(k in q for k in ["create", "add", "insert", "new user", "banao", "bana"]):
        # Match name from 'create talha', 'create user talha', 'create a user named talha'
        name_m = re.search(r'(?:create|add|insert|banao|bana)\s+(?:a\s+)?(?:user\s+)?(?:named\s+)?([A-Za-z0-9_\.-]+)', user_query, re.IGNORECASE)
        name_text = None
        if name_m:
            candidate = name_m.group(1).strip()
            if candidate.lower() not in ["user", "the", "a", "an", "new", "named"]:
                name_text = candidate

        fields = {}
        if name_text:
            fields['name'] = name_text
        if email_m: fields['email'] = email_m.group(0)
        if phone_m: fields['phone'] = phone_m.group(0)
        return {"intent": "CREATE", "fields": fields}

    # COUNT intent
    if "count" in q or "how many" in q or "total users" in q:
        return {"intent": "COUNT", "fields": {}}

    return {"intent": "UNKNOWN", "fields": {}}

def handle_chat(request: ChatRequest) -> ChatResponse:
    """Main entry point for /chat supporting email/name lookups, optional names, and multi-turn state."""
    try:
        state = conversation.get_state(request.session_id)
        if state is None:
            conversation.init_session(request.session_id, request.user_id)
            state = conversation.get_state(request.session_id)

        current_collected = state.get("collected", {})
        current_intent = state.get("intent")

        context_prompt = (
            f"{SYSTEM_PROMPT}\n\n"
            f"Current Pending Session Data: {json.dumps(current_collected)}\n"
            f"Current Pending Intent: {current_intent or 'None'}\n"
            f"User Message: {request.query}"
        )

        parsed = None
        try:
            llm_output = llm.call_gemini(context_prompt)
            if llm_output:
                parsed = _parse_llm_response(llm_output)
        except Exception as err:
            print(f"[WARN] Gemini call fallback: {err}")
            parsed = None

        if not parsed or not parsed.get("intent") or parsed.get("intent") == "UNKNOWN":
            parsed_fallback = _rule_based_intent_parser(request.query, current_collected, current_intent)
            if parsed_fallback.get("intent") != "UNKNOWN":
                parsed = parsed_fallback

        if not parsed:
            parsed = {"intent": "UNKNOWN", "fields": {}}

        new_intent = parsed.get("intent")
        new_fields = parsed.get("fields", {}) or {}

        clean_new_fields = {k: v for k, v in new_fields.items() if v and str(v).lower() != "null"}

        active_intent = new_intent if (new_intent and new_intent != "UNKNOWN") else current_intent
        merged_fields = {**current_collected, **clean_new_fields}

        conversation.update_state(
            request.session_id,
            intent=active_intent,
            collected=merged_fields
        )

        is_urdu = _is_roman_urdu(request.query)

        # ---------------------------------------------------------
        # INTENT 1: CREATE
        # ---------------------------------------------------------
        if active_intent == "CREATE":
            email = merged_fields.get("email")
            phone = merged_fields.get("phone")
            name = merged_fields.get("name")
            address = merged_fields.get("address")

            # Address requirement logic:
            # ONLY skip address if the request is an email-first quick create ("add user x@y.com with phone 123" without a name).
            # For ALL OTHER creation flows ("create talha", "create a user named Bilal", "create user Ali with email x and phone y"),
            # address is ALWAYS required before saving.
            is_email_quick_create = bool(email and phone and not name and not current_collected.get("name"))
            
            missing = []
            if not email: missing.append("email")
            if not phone: missing.append("phone")
            if not is_email_quick_create and not address: missing.append("address")

            if missing:
                missing_str = ", ".join(missing)
                name_display = f"'{name}'" if name else "the user"
                if is_urdu:
                    return ChatResponse(response=f"{name_display} ko add karne ke liye, meharbani karke unka {missing_str} dein.")
                return ChatResponse(response=f"To add {name_display}, please provide their {missing_str}.")

            if not name:
                name = email.split("@")[0].capitalize()

            try:
                user_data = UserCreate(
                    name=name,
                    email=email,
                    phone=phone,
                    address=address
                )
                created = user_service.create_user(user_data)
                user_id = created.get("id") if isinstance(created, dict) else getattr(created, "id", None)
                conversation.clear_state(request.session_id)
                if is_urdu:
                    return ChatResponse(response=f"{name} ({email}) kamyabi se add ho gaya hai with ID {user_id}.")
                return ChatResponse(response=f"User {name} ({email}) has been added successfully with ID {user_id}.")
            except Exception as e:
                detail = getattr(e, 'detail', str(e))
                return ChatResponse(response=f"Could not create user: {detail}")

        # ---------------------------------------------------------
        # INTENT 2: UPDATE
        # ---------------------------------------------------------
        elif active_intent == "UPDATE":
            target_id = merged_fields.get("target_identifier") or merged_fields.get("target_name")
            user_obj = _find_user_by_identifier(merged_fields.get("user_id"), target_id, merged_fields.get("target_name"))
            
            if not user_obj:
                conversation.clear_state(request.session_id)
                if is_urdu:
                    return ChatResponse(response=f"Maazrat, '{target_id}' ka koi user nahi mila.")
                return ChatResponse(response=f"Sorry, user '{target_id}' was not found.")

            uid = user_obj["id"]
            uname = user_obj["name"]
            uemail = user_obj["email"]
            merged_fields["user_id"] = uid

            field_to_update = merged_fields.get("update_field")
            new_value = merged_fields.get("update_value")

            if not field_to_update:
                if is_urdu:
                    return ChatResponse(response=f"Aap {uname} ({uemail}) ki konsi detail update karna chahte hain? (email, phone, ya address)")
                return ChatResponse(response=f"What would you like to update for {uname} ({uemail})? (email, phone, or address)")

            if not new_value:
                if is_urdu:
                    return ChatResponse(response=f"{uname} ke liye naya {field_to_update} batayein:")
                return ChatResponse(response=f"Please provide the new {field_to_update} for {uname}:")

            try:
                upd_payload = UserUpdate(**{field_to_update: new_value})
                user_service.update_user(uid, upd_payload)
                conversation.clear_state(request.session_id)
                if is_urdu:
                    return ChatResponse(response=f"{uname} ka {field_to_update} kamyabi se '{new_value}' par update ho gaya hai.")
                return ChatResponse(response=f"{uname}'s {field_to_update} has been updated to {new_value}.")
            except Exception as e:
                detail = getattr(e, 'detail', str(e))
                return ChatResponse(response=f"Could not update user: {detail}")

        # ---------------------------------------------------------
        # INTENT 3: DELETE
        # ---------------------------------------------------------
        elif active_intent == "DELETE":
            target_id = merged_fields.get("target_identifier") or merged_fields.get("target_name")
            user_obj = _find_user_by_identifier(merged_fields.get("user_id"), target_id, merged_fields.get("target_name"))
            
            if not user_obj:
                conversation.clear_state(request.session_id)
                if is_urdu:
                    return ChatResponse(response=f"Maazrat, '{target_id}' ka koi user nahi mila.")
                return ChatResponse(response=f"Sorry, user '{target_id}' was not found.")

            uid = user_obj["id"]
            uname = user_obj["name"]
            uemail = user_obj["email"]
            merged_fields["user_id"] = uid

            confirmation = merged_fields.get("confirmation")

            if not confirmation or str(confirmation).lower() not in ["yes", "yep", "yeah", "haan", "ha", "confirm"]:
                if is_urdu:
                    return ChatResponse(response=f"Kya aap yaqeenan {uname} ({uemail}, ID {uid}) ko delete karna chahte hain? Taseeq ke liye 'yes' ya 'haan' likhein.")
                return ChatResponse(response=f"Are you sure you want to delete {uname} ({uemail}, ID {uid})? Reply 'yes' to confirm.")

            try:
                user_service.delete_user(uid)
                conversation.clear_state(request.session_id)
                if is_urdu:
                    return ChatResponse(response=f"{uname} ({uemail}) ko kamyabi se delete kar diya gaya hai.")
                return ChatResponse(response=f"User {uname} ({uemail}) has been deleted successfully.")
            except Exception as e:
                detail = getattr(e, 'detail', str(e))
                return ChatResponse(response=f"Could not delete user: {detail}")

        # ---------------------------------------------------------
        # INTENT 4: READ
        # ---------------------------------------------------------
        elif active_intent == "READ":
            target_id = merged_fields.get("target_identifier") or merged_fields.get("target_name")
            user_obj = _find_user_by_identifier(merged_fields.get("user_id"), target_id, merged_fields.get("target_name"))
            
            if not user_obj:
                conversation.clear_state(request.session_id)
                target_str = target_id or "that user"
                if is_urdu:
                    return ChatResponse(response=f"Maazrat, '{target_str}' ka koi record nahi mila.")
                return ChatResponse(response=f"Sorry, no record found for '{target_str}'.")

            conversation.clear_state(request.session_id)
            addr_str = user_obj.get('address') or 'N/A'
            return ChatResponse(response=f"User Details: ID={user_obj.get('id')}, Name={user_obj.get('name')}, Email={user_obj.get('email')}, Phone={user_obj.get('phone')}, Address={addr_str}")

        # ---------------------------------------------------------
        # INTENT 5: COUNT
        # ---------------------------------------------------------
        elif active_intent == "COUNT":
            count = user_service.count_users()
            conversation.clear_state(request.session_id)
            if is_urdu:
                return ChatResponse(response=f"Total users ki taadad: {count}")
            return ChatResponse(response=f"Total users: {count}")

        # ---------------------------------------------------------
        # INTENT 6: HELP
        # ---------------------------------------------------------
        elif active_intent == "HELP":
            conversation.clear_state(request.session_id)
            if is_urdu:
                return ChatResponse(response="Main naye users add karne, dikhane, update karne, delete karne aur total count batane mein madad kar sakta hoon.")
            return ChatResponse(response="You can ask me to create, read, update, delete, search, or count users.")

        if is_urdu:
            return ChatResponse(response="Maazrat, main aap ki request nahi samajh saka. Kya aap wazahat kar sakte hain?")
        return ChatResponse(response="I'm not sure how to handle that request. Could you please rephrase?")

    except Exception as exc:
        print(f"[ERROR] Exception in handle_chat: {exc}")
        return ChatResponse(response="Sorry, I couldn't process that request right now. Could you please rephrase?")
