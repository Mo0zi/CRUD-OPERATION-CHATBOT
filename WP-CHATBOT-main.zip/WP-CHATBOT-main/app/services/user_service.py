# app/services/user_service.py

import logging
from typing import List, Dict, Any, Optional

from fastapi import HTTPException, status

from .. import db, models

logger = logging.getLogger(__name__)


def create_user(user: models.UserCreate) -> Dict[str, Any]:
    existing = db.get_user_by_email(user.email)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A user with this e‑mail already exists.",
        )
    try:
        user_id = db.create_user(
            name=user.name or user.email.split("@")[0].capitalize(),
            email=user.email,
            phone=user.phone,
            address=user.address,
        )
    except Exception as exc:
        logger.error("Failed to create user: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Unable to create user.",
        )
    return db.get_user_by_id(user_id)


def get_user(user_id: int) -> Dict[str, Any]:
    user = db.get_user_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
        )
    return user


def list_users() -> List[Dict[str, Any]]:
    return db.list_all_users()


def update_user(user_id: int, payload: models.UserUpdate) -> Dict[str, Any]:
    if not db.get_user_by_id(user_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
        )
    if payload.email:
        existing = db.get_user_by_email(payload.email)
        if existing and existing["id"] != user_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Another user with this e‑mail already exists.",
            )
    fields = payload.dict(exclude_unset=True)
    if not fields:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No fields provided for update",
        )
    db.update_user(user_id, fields)
    updated = db.get_user_by_id(user_id)
    if not updated:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found after update"
        )
    return updated


def delete_user(user_id: int) -> None:
    rows = db.delete_user(user_id)
    if rows == 0:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
        )


def count_users() -> int:
    return db.count_users()


def search_users(
    name: Optional[str] = None,
    email: Optional[str] = None,
    address: Optional[str] = None,
) -> List[Dict[str, Any]]:
    return db.search_users(name=name, email=email, address=address)
