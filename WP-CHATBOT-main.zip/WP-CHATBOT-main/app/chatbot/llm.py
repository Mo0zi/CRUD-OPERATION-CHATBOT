import os
from typing import Optional, Union, List
import google.generativeai as genai
from ..config import GOOGLE_GEMINI_API_KEY, GEMINI_MODEL

def _get_api_key() -> str:
    from app.config import GOOGLE_GEMINI_API_KEY
    return os.getenv("GOOGLE_GEMINI_API_KEY") or GOOGLE_GEMINI_API_KEY

def generate_gemini_response(system_prompt: str, user_prompt: str, temperature: float = 0.7, max_output_tokens: Optional[int] = None) -> str:
    api_key = _get_api_key()
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(
        model_name=GEMINI_MODEL,
        generation_config=genai.GenerationConfig(
            temperature=temperature,
            max_output_tokens=max_output_tokens,
        ),
    )
    # Combine system and user prompts
    response = model.generate_content([system_prompt, user_prompt])
    # Ensure we return a plain string
    return (response.text or "").strip()

def call_gemini(prompt: Union[str, List[str]]) -> str:
    """Convenient wrapper usable by the rest of the codebase.

    * If `prompt` is a string, it is treated as the user message.
    * If `prompt` is a list, the first element is used as the system prompt and the
      remaining elements are concatenated (newline‑separated) to form the user prompt.
    * Handles Gemini SDK errors, especially empty responses.
    """
    if isinstance(prompt, list):
        system_prompt = prompt[0] if prompt else ""
        user_prompt = "\n".join(prompt[1:]) if len(prompt) > 1 else ""
    else:
        system_prompt = ""
        user_prompt = prompt
    try:
        response = generate_gemini_response(system_prompt, user_prompt)
        # Gemini may raise a ValueError if both text and tool calls are empty.
        if not response:
            # Log diagnostic info (avoid leaking API key)
            print("[WARN] Gemini returned empty response for prompt.")
            return ""
        return response
    except Exception as e:
        # Log the exception and re‑raise a simpler error for the caller.
        print(f"[ERROR] Gemini call failed: {e}")
        # Propagate a generic error string – the caller can decide how to handle.
        raise RuntimeError(f"Gemini API error: {e}")
