import os
from typing import List
from app.config import EMBEDDING_MODEL_NAME

# Load a single SentenceTransformer instance (lazy singleton)
_model = None

def get_model():
    """Return a cached SentenceTransformer instance.

    The model is loaded on first call using the name from config.
    Subsequent calls reuse the same object to avoid re‑loading overhead.
    """
    global _model
    if _model is None:
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    return _model

def embed_texts(texts: List[str]) -> List[List[float]]:
    """Encode a list of strings into normalized embeddings.

    Parameters
    ----------
    texts: List[str]
        The raw text strings to embed.

    Returns
    -------
    List[List[float]]
        A list of embedding vectors (each a list of floats).
    """
    model = get_model()
    return model.encode(texts, normalize_embeddings=True).tolist()
