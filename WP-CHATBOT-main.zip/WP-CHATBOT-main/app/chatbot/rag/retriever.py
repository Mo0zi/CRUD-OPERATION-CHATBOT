# app/chatbot/rag/retriever.py
"""RAG retriever utilities.

Provides a high‑level function that, given a user query, returns the most similar
documents (or document IDs) from the FAISS index.

In the current implementation the index stores raw document strings – for the user
management chatbot we will later index user information (e.g., name, email, city).
For now the retriever simply returns the raw FAISS search results as a tuple of
(distances, indices).
"""

from typing import List, Tuple

from .vector_store import search


def retrieve(query: str, k: int = 5) -> Tuple[List[float], List[int]]:
    """Retrieve the top‑*k* most similar entries for *query*.

    Args:
        query: The natural‑language query string.
        k: Number of nearest neighbours to return.

    Returns:
        A tuple ``(distances, indices)`` where each element is a list of ``k`` values.
        ``distances`` are the L2 distances from the query embedding; ``indices`` are the
        corresponding document IDs stored in the FAISS index.
    """
    distances, indices = search(query, k=k)
    return distances, indices
