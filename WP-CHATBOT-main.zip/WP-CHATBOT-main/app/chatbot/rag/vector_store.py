# app/chatbot/rag/vector_store.py
"""RAG vector store utilities.

This module provides a thin wrapper around a FAISS IndexFlatL2 that stores embeddings for
user records or any arbitrary documents.  It mirrors the functionality that previously lived
in ``app/vector_store.py`` but is scoped to the ``chatbot.rag`` package so that the RAG
components are self‑contained.

The index is persisted as ``store.pkl`` inside the ``FAISS_INDEX_DIR`` defined in
``app.config``.  On first run the index is created automatically.
"""

import os
import pickle
from pathlib import Path
from typing import List

import faiss

from app.config import FAISS_INDEX_DIR, EMBEDDING_MODEL_NAME
from .embeddings import embed_texts

# Global singleton for the FAISS index
_index: faiss.IndexFlatL2 | None = None


def _ensure_index(dim: int = 384) -> faiss.IndexFlatL2:
    """Return the global FAISS index, creating it if necessary.

    The index is persisted to ``FAISS_INDEX_DIR/store.pkl``.  If the file does not exist a
    new empty ``IndexFlatL2`` is created with the given ``dim`` (default 384, matching the
    SentenceTransformer output dimension).
    """
    global _index
    if _index is not None:
        return _index

    # Make sure the directory exists
    os.makedirs(FAISS_INDEX_DIR, exist_ok=True)
    index_path = Path(FAISS_INDEX_DIR) / "store.pkl"

    if index_path.exists():
        with open(index_path, "rb") as f:
            _index = pickle.load(f)
    else:
        _index = faiss.IndexFlatL2(dim)
        # Save the empty index for future loads
        with open(index_path, "wb") as f:
            pickle.dump(_index, f)
    return _index


def add_documents(documents: List[str]) -> None:
    """Encode *documents* and add them to the FAISS index.

    The function updates the persisted ``store.pkl`` file so that a later process can load
    the augmented index.
    """
    if not documents:
        return
    index = _ensure_index()
    vectors = embed_texts(documents)
    index.add(vectors)
    # Persist updated index
    with open(Path(FAISS_INDEX_DIR) / "store.pkl", "wb") as f:
        pickle.dump(index, f)


def search(query: str, k: int = 5) -> tuple[List[float], List[int]]:
    """Return the top‑*k* similar vectors for *query*.

    Returns a tuple ``(distances, indices)`` where each list corresponds to the results
    from the FAISS ``search`` call.
    """
    index = _ensure_index()
    q_vec = embed_texts([query])[0]
    distances, indices = index.search([q_vec], k)
    # Convert from numpy arrays to plain Python lists for easier downstream handling
    return distances.tolist()[0], indices.tolist()[0]
