import threading
from typing import Dict, Any, Optional

_state_lock = threading.Lock()
_state: Dict[str, Dict[str, Any]] = {}

def init_session(session_id: str, user_id: str) -> None:
    """Initialize a new conversation state for a session.

    The state tracks:
    - ``intent``: parsed action (CREATE, READ, UPDATE, DELETE, SEARCH, COUNT, HELP, UNKNOWN)
    - ``collected``: fields already supplied by the user
    - ``missing``: list of required fields still needed
    - ``awaiting_confirmation``: flag when LLM asks for confirmation before a destructive action
    - ``last_message``: last user message for context
    """
    with _state_lock:
        _state[session_id] = {
            "user_id": user_id,
            "intent": None,
            "collected": {},
            "missing": [],
            "awaiting_confirmation": False,
            "last_message": None,
        }

def get_state(session_id: str) -> Optional[Dict[str, Any]]:
    """Return the stored state for a session, or ``None`` if not found."""
    with _state_lock:
        return _state.get(session_id)

def update_state(session_id: str, **updates: Any) -> None:
    """Merge ``updates`` into the existing state for ``session_id``.

    Example::
        update_state(session_id, intent="CREATE", collected={"name": "Bob"})
    """
    with _state_lock:
        if session_id not in _state:
            raise KeyError(f"Session {session_id} not initialized")
        _state[session_id].update(updates)

def clear_state(session_id: str) -> None:
    """Remove a session's state – typically after the conversation ends."""
    with _state_lock:
        _state.pop(session_id, None)

