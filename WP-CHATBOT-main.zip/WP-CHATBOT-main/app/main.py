import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from app.routes import router
from app.vector_store import set_vector_store, create_vector_store, load_vector_store
from app.config import FAISS_INDEX_DIR

app = FastAPI(
    title="User Management Chatbot",
    description="Admin chatbot for CRUD operations on users with Gemini 2.5 Flash",
    version="0.1.0",
)

# CORS – allow development and production origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Detect React production build dist directory
base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
dist_dir = os.path.join(base_dir, "frontend_dist")
if not os.path.exists(dist_dir):
    dist_dir = os.path.join(base_dir, "frontend", "dist")

static_dir = os.path.join(base_dir, "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

if os.path.exists(dist_dir):
    app.mount("/assets", StaticFiles(directory=os.path.join(dist_dir, "assets")), name="assets")

# Include API routes
app.include_router(router)

# Lifespan: load or create FAISS index safely
@app.on_event("startup")
async def startup_event():
    try:
        if os.path.exists(os.path.join(FAISS_INDEX_DIR, "store.pkl")):
            vs = load_vector_store()
        else:
            vs = create_vector_store()
        set_vector_store(vs)
    except Exception as e:
        print(f"[WARN] FAISS Vector Store startup warning: {e}")

# Serve React index.html for frontend routes in production, or fallback static index.html
@app.get("/{full_path:path}")
async def serve_frontend(full_path: str):
    if full_path.startswith("api/") or full_path.startswith("static/"):
        return {"detail": "Not Found"}
    
    if os.path.exists(dist_dir):
        file_path = os.path.join(dist_dir, full_path)
        if os.path.isfile(file_path):
            return FileResponse(file_path)
        index_file = os.path.join(dist_dir, "index.html")
        if os.path.exists(index_file):
            return FileResponse(index_file)
            
    index_fallback = os.path.join(static_dir, "index.html")
    if os.path.exists(index_fallback):
        return FileResponse(index_fallback)
    return {"message": "API is running"}
