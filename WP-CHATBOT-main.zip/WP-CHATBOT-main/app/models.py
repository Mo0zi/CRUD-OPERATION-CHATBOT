from pydantic import BaseModel, EmailStr, Field
from typing import Optional

class AdminLoginRequest(BaseModel):
    email: EmailStr

class AdminLoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserCreate(BaseModel):
    name: Optional[str] = None
    email: EmailStr
    phone: str = Field(..., pattern=r"^\+?[0-9]{7,15}$")
    address: Optional[str] = None

class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(None, pattern=r"^\+?[0-9]{7,15}$")
    address: Optional[str] = None

class UserOut(BaseModel):
    id: int
    name: Optional[str] = None
    email: EmailStr
    phone: str
    address: Optional[str] = None

class ChatRequest(BaseModel):
    query: str
    session_id: str
    user_id: str = "admin"

class ChatResponse(BaseModel):
    response: str
