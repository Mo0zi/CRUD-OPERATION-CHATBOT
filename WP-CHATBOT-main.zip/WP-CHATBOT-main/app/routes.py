# app/routes.py

from fastapi import APIRouter, Depends, HTTPException, status
from typing import List
from app import models, db
from .services.auth import get_current_admin, create_access_token
from .services import user_service
from .services import chat_service

router = APIRouter(prefix="/api", tags=["admin"])

@router.post("/login", response_model=models.AdminLoginResponse)
def admin_login(payload: models.AdminLoginRequest):
    try:
        email = payload.email.strip().lower() if payload.email else ""

        # 1. System Admins (always authorized)
        admin_emails = ["admin@example.com", "chatbot@gmail.com"]
        if email in admin_emails:
            token = create_access_token(email)
            return models.AdminLoginResponse(access_token=token)

        # 2. Database Registered Users (auto-authorized by email presence)
        existing_user = db.get_user_by_email(email)
        if existing_user:
            token = create_access_token(email)
            return models.AdminLoginResponse(access_token=token)

        # 3. Unauthorized if email not found
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email not found. Please contact an administrator to be added first."
        )
    except HTTPException:
        raise
    except Exception as e:
        print(f"[ERROR] Login route exception: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

# CRUD User Endpoints (protected)
@router.post("/users", response_model=models.UserOut, status_code=status.HTTP_201_CREATED)
def create_user(user: models.UserCreate, admin=Depends(get_current_admin)):
    created_user = user_service.create_user(user)
    return created_user

@router.get("/users/{user_id}", response_model=models.UserOut)
def read_user(user_id: int, admin=Depends(get_current_admin)):
    return user_service.get_user(user_id)

@router.get("/users", response_model=List[models.UserOut])
def list_users(admin=Depends(get_current_admin)):
    return user_service.list_users()

@router.put("/users/{user_id}", response_model=models.UserOut)
def update_user(user_id: int, payload: models.UserUpdate, admin=Depends(get_current_admin)):
    return user_service.update_user(user_id, payload)

@router.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: int, admin=Depends(get_current_admin)):
    user_service.delete_user(user_id)
    return

@router.get("/users/count")
def count_users(admin=Depends(get_current_admin)):
    return {"count": user_service.count_users()}

# Chat endpoint
@router.post("/chat", response_model=models.ChatResponse)
def chat(request: models.ChatRequest, admin=Depends(get_current_admin)):
    return chat_service.handle_chat(request)
