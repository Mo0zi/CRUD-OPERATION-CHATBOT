import os
import pickle
from pathlib import Path

import faiss

from app.config import FAISS_INDEX_DIR, EMBEDDING_MODEL_NAME

# Global variable to hold the FAISS index instance
_vector_store = None

def set_vector_store(vs):
    """Set the global vector store instance used by the application."""
    global _vector_store
    _vector_store = vs

def get_vector_store():
    """Retrieve the global vector store; raises if not initialized."""
    if _vector_store is None:
        raise RuntimeError("Vector store not initialized. Call set_vector_store during startup.")
    return _vector_store

def _load_model():
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(EMBEDDING_MODEL_NAME)

def create_vector_store(dim: int = 384):
    """Create a new empty FAISS IndexFlatL2 and return it."""
    index = faiss.IndexFlatL2(dim)
    # Save empty index for future loads
    os.makedirs(FAISS_INDEX_DIR, exist_ok=True)
    with open(os.path.join(FAISS_INDEX_DIR, "store.pkl"), "wb") as f:
        pickle.dump(index, f)
    return index

def load_vector_store():
    """Load FAISS index from disk."""
    index_path = os.path.join(FAISS_INDEX_DIR, "store.pkl")
    if not os.path.exists(index_path):
        raise FileNotFoundError("FAISS index not found. Run create_vector_store first.")
    with open(index_path, "rb") as f:
        index = pickle.load(f)
    # Set as global store for runtime use
    set_vector_store(index)
    return index

def add_documents_to_index(documents: list[str]):
    """Encode documents and add them to the FAISS index."""
    model = _load_model()
    vectors = model.encode(documents, normalize_embeddings=True)
    index = get_vector_store()
    index.add(vectors)
    # Persist updated index
    with open(os.path.join(FAISS_INDEX_DIR, "store.pkl"), "wb") as f:
        pickle.dump(index, f)
    return index

def search_similar(query: str, k: int = 5):
    """Return top-k similar document IDs for a query string."""
    model = _load_model()
    q_vec = model.encode([query], normalize_embeddings=True)
    index = get_vector_store()
    distances, indices = index.search(q_vec, k)
    return distances.tolist(), indices.tolist()
