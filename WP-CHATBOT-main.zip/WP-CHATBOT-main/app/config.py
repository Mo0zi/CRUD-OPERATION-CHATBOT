import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from project root
BASE_DIR = Path(__file__).resolve().parent.parent
env_path = BASE_DIR / '.env'
if env_path.exists():
    load_dotenv(dotenv_path=env_path, override=True)
else:
    load_dotenv(override=True)

# JWT configuration
JWT_SECRET = os.getenv('JWT_SECRET', 'replace-this-with-a-secure-secret')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_SECONDS = 3600  # 1 hour

# Gemini configuration (Google Gemini 2.5 Flash)
GOOGLE_GEMINI_API_KEY = os.getenv('GOOGLE_GEMINI_API_KEY', 'dummy-key')
GEMINI_MODEL = 'gemini-flash-lite-latest'

# Embedding model
EMBEDDING_MODEL_NAME = 'sentence-transformers/all-MiniLM-L6-v2'

# FAISS index directory
FAISS_INDEX_DIR = str(BASE_DIR / 'faiss_index')
