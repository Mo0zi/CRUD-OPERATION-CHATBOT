import os
import sqlite3
from difflib import SequenceMatcher
from pathlib import Path
from typing import List, Dict, Any, Optional

# Database file path
BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / 'data' / 'user_management.db'

# Ensure data directory exists
os.makedirs(DB_PATH.parent, exist_ok=True)

def get_connection():
    """Create a new SQLite connection with row_factory for dict-like access."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize SQLite table and dynamically migrate schema if needed."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(users)")
    cols = [row["name"] for row in cur.fetchall()]
    
    if not cols:
        schema_path = BASE_DIR / 'schema.sql'
        if schema_path.exists():
            with open(schema_path, 'r') as f:
                lines = [line for line in f if not line.strip().upper().startswith(('CREATE DATABASE', 'USE '))]
                conn.executescript(''.join(lines))
    else:
        if "address" not in cols:
            try:
                cur.execute("ALTER TABLE users ADD COLUMN address TEXT")
                conn.commit()
            except Exception as e:
                print(f"[WARN] Migration warning: {e}")
    conn.close()

try:
    init_db()
except Exception as e:
    print(f"[WARN] Database startup warning: {e}")

# CRUD operations using SQLite

def create_user(name: str, email: str, phone: Optional[str] = None, address: Optional[str] = None, **kwargs) -> int:
    query = """
        INSERT INTO users (name, email, phone, address)
        VALUES (?, ?, ?, ?)
    """
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(query, (name, email, phone, address))
        conn.commit()
        return cur.lastrowid

def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    query = "SELECT id, name, email, phone, address, created_at, updated_at FROM users WHERE id = ?"
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(query, (user_id,))
        row = cur.fetchone()
        return dict(row) if row else None

def get_user_by_email(email: str) -> Optional[Dict[str, Any]]:
    query = "SELECT id, name, email, phone, address, created_at, updated_at FROM users WHERE email = ?"
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(query, (email,))
        row = cur.fetchone()
        return dict(row) if row else None

def find_user_by_name_fuzzy(name_query: str, threshold: float = 0.55) -> Optional[Dict[str, Any]]:
    """Fuzzy/case-insensitive search for a user by name."""
    if not name_query:
        return None
    target = name_query.strip().lower()
    
    all_users = list_all_users()
    best_match = None
    best_ratio = 0.0

    # 1. Direct exact or boundary word match first
    for user in all_users:
        uname = user["name"].strip().lower()
        if uname == target:
            return user

    for user in all_users:
        uname = user["name"].strip().lower()
        if target in uname.split() or uname in target.split():
            return user

    # 2. Sequence matcher fallback
    for user in all_users:
        uname = user["name"].strip().lower()
        ratio = SequenceMatcher(None, target, uname).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_match = user

    if best_ratio >= threshold:
        return best_match
    return None

def search_users(name: Optional[str] = None, email: Optional[str] = None, address: Optional[str] = None) -> List[Dict[str, Any]]:
    base = "SELECT id, name, email, phone, address FROM users WHERE 1=1"
    params: List[Any] = []
    if name:
        base += " AND name LIKE ?"
        params.append(f"%{name}%")
    if email:
        base += " AND email LIKE ?"
        params.append(f"%{email}%")
    if address:
        base += " AND address LIKE ?"
        params.append(f"%{address}%")
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(base, params)
        return [dict(row) for row in cur.fetchall()]

def update_user(user_id: int, fields: Dict[str, Any]) -> int:
    valid_fields = {k: v for k, v in fields.items() if k in ["name", "email", "phone", "address"]}
    if not valid_fields:
        return 0
    set_clause = ", ".join([f"{k} = ?" for k in valid_fields.keys()])
    params = list(valid_fields.values()) + [user_id]
    query = f"UPDATE users SET {set_clause} WHERE id = ?"
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(query, params)
        conn.commit()
        return conn.total_changes

def delete_user(user_id: int) -> int:
    query = "DELETE FROM users WHERE id = ?"
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(query, (user_id,))
        conn.commit()
        return conn.total_changes

def count_users() -> int:
    query = "SELECT COUNT(*) as cnt FROM users"
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(query)
        result = cur.fetchone()
        return result["cnt"] if result else 0

def list_all_users() -> List[Dict[str, Any]]:
    query = "SELECT id, name, email, phone, address FROM users"
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(query)
        return [dict(row) for row in cur.fetchall()]
