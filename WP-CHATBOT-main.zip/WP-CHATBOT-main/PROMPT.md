# Prompt Engineering & System Prompt Specifications

This document outlines the prompt engineering design, system prompt contracts, multilingual rules, and evaluation examples used by the **Google Gemini AI Engine** in the User Management AI Chatbot.

---

## 📜 1. Master System Prompt

The following system prompt is passed to Google Gemini (`gemini-2.5-flash` / `gemini-1.5-flash`) on every conversation turn:

```text
You are an AI admin assistant for user management.
The user may write in English, Roman Urdu/Hindi, or a mix of both. Understand the intent regardless of language.
Respond ONLY with a valid JSON object (no markdown, no stray text) with two keys:
1. 'intent': One of 'CREATE', 'READ', 'UPDATE', 'DELETE', 'SEARCH', 'COUNT', 'HELP', or 'UNKNOWN'.
2. 'fields': A dictionary of extracted parameters (name, email, phone, city, country, user_id, query).
3. 'message' (optional): A polite conversational message in the user's language (English or Roman Urdu) if details are missing or if explaining what's needed.

Rules for CREATE:
- Required fields to create a user: 'name', 'email', 'phone'.
- If name is present but email or phone is missing, set intent to 'UNKNOWN' and include a polite 'message' in the user's language asking for the missing fields (e.g. for Roman Urdu: 'Afaq ko add karne ke liye, meharbani karke unka email aur phone number dein.').

Rules for READ/UPDATE/DELETE:
- If user_id is missing, set intent to 'UNKNOWN' and ask for user ID in the user's language.
```

---

## 🎯 2. Intent Classification Taxonomy

| Intent | Code | Example Query (English) | Example Query (Roman Urdu) | Extracted Fields |
|---|---|---|---|---|
| **Create User** | `CREATE` | `"create user Sarah, email s@a.com, phone 123"` | `"afaq naam ka user banao, email a@t.com, phone 0300"` | `name`, `email`, `phone`, `city`, `country` |
| **Read User** | `READ` | `"get user 1"`, `"view user 5"` | `"user 1 ki details dikhao"` | `user_id` |
| **Update User** | `UPDATE` | `"update user 2 name Bob"` | `"user 2 ka naam change karo"` | `user_id`, `name`, `email`, etc. |
| **Delete User** | `DELETE` | `"delete user 4"` | `"user 4 ko delete kar do"` | `user_id` |
| **Count Users** | `COUNT` | `"count users"`, `"total users"` | `"kul kitne users hain"` | `{}` |
| **Search Users** | `SEARCH` | `"find users from Seattle"` | `"seattle ke users dhoondo"` | `query` |
| **Help / Greetings** | `HELP` | `"help"`, `"what can you do"` | `"kya kar sakte ho"`, `"madad"` | `{}` |
| **Ambiguous / Incomplete** | `UNKNOWN` | `"add afaq"` | `"afaq ko add kr do"` | `name` (plus clarifying `message`) |

---

## 💬 3. Multilingual Handling Rules (English & Roman Urdu)

1. **Detection:** Queries containing words like `ko`, `kr`, `kar`, `banao`, `bana`, `do`, `dein`, `ka`, `naam`, `nayi` are flagged as Roman Urdu.
2. **Clarification Language Matching:**
   - English ambiguous request (`"add afaq"`):
     `"To add user 'afaq', please provide their email and phone number."`
   - Roman Urdu ambiguous request (`"afaq ko add kr do"`):
     `"'afaq' ko add karne ke liye, meharbani karke unka email aur phone number dein."`
3. **Execution Success Language Matching:**
   - English completion: `"User created with ID 5."`
   - Roman Urdu completion: `"User ID 5 ke sath kamyabi se add ho gaya hai."`

---

## 🧪 4. Prompt Evaluation Examples

### Example 1: Full Creation Query (Roman Urdu)
- **Input Prompt:** `"afaq naam ka user banao, email afaq@test.com, phone 03001234567, city Lahore"`
- **Expected Gemini JSON Output:**
  ```json
  {
    "intent": "CREATE",
    "fields": {
      "name": "afaq",
      "email": "afaq@test.com",
      "phone": "03001234567",
      "city": "Lahore"
    }
  }
  ```
- **Backend Execution:** Creates user in SQLite database and returns `"User ID 5 ke sath kamyabi se add ho gaya hai."`

---

### Example 2: Ambiguous Creation Query (Roman Urdu)
- **Input Prompt:** `"afaq ko add kr do"`
- **Expected Gemini JSON Output:**
  ```json
  {
    "intent": "UNKNOWN",
    "fields": {
      "name": "afaq"
    },
    "message": "'afaq' ko add karne ke liye, meharbani karke unka email aur phone number dein."
  }
  ```
- **Backend Execution:** Does not crash; returns conversational request for missing fields.

---

### Example 3: Count Query (English)
- **Input Prompt:** `"count users"`
- **Expected Gemini JSON Output:**
  ```json
  {
    "intent": "COUNT",
    "fields": {}
  }
  ```
- **Backend Execution:** Runs `SELECT COUNT(*) FROM users` and returns `"Total users: 5"`.
