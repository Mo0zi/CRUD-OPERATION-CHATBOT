# scripts/run_migration.py

import os
import pymysql
from pymysql.cursors import DictCursor
from pathlib import Path

# Load env vars (same as app config) – minimal for migration
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
env_path = BASE_DIR / '.env'
if env_path.exists():
    load_dotenv(dotenv_path=env_path)

MYSQL_HOST = os.getenv('MYSQL_HOST', 'localhost')
MYSQL_PORT = int(os.getenv('MYSQL_PORT', '3306'))
MYSQL_USER = os.getenv('MYSQL_USER', 'root')
MYSQL_PASSWORD = os.getenv('MYSQL_PASSWORD', '')
MYSQL_DB = os.getenv('MYSQL_DB', 'user_management')

SQL_FILE = Path(__file__).with_name('create_tables.sql')


def get_connection():
    return pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        cursorclass=DictCursor,
        autocommit=True,
    )

def run_migration():
    if not SQL_FILE.exists():
        raise FileNotFoundError(f"Migration file {SQL_FILE} not found")
    with open(SQL_FILE, 'r') as f:
        sql_script = f.read()
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            for statement in sql_script.split(';'):
                stmt = statement.strip()
                if stmt:
                    cur.execute(stmt)
        print('✅ Migration applied successfully')
    finally:
        conn.close()

if __name__ == '__main__':
    run_migration()
