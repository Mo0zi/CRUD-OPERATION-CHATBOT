import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { Bot, Send, User, Sparkles, RefreshCw, Command } from 'lucide-react';

const INITIAL_WELCOME_MESSAGE = [
  {
    id: 1,
    sender: 'bot',
    text: 'Hello! I am your AI Admin Assistant connected to Google Gemini & SQLite. You can ask me to count users, get user details, create or delete user records!',
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  },
];

const ChatPage = () => {
  const { authFetch } = useAuth();

  // Load chat messages from localStorage so navigation between Dashboard & Chat retains history
  const [messages, setMessages] = useState(() => {
    const saved = localStorage.getItem('chat_messages');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {
        console.error('Failed to parse saved chat messages:', e);
      }
    }
    return INITIAL_WELCOME_MESSAGE;
  });

  const [inputQuery, setInputQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const [sessionId, setSessionId] = useState(() => {
    const saved = localStorage.getItem('chat_session_id');
    if (saved) return saved;
    const newId = 'sess_' + Math.random().toString(36).substring(2, 9);
    localStorage.setItem('chat_session_id', newId);
    return newId;
  });

  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Sync messages to localStorage whenever messages state changes
  useEffect(() => {
    localStorage.setItem('chat_messages', JSON.stringify(messages));
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendMessage = async (queryText = inputQuery) => {
    const text = queryText.trim();
    if (!text || isTyping) return;

    const userMsg = {
      id: Date.now(),
      sender: 'user',
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsTyping(true);

    try {
      const res = await authFetch('/chat', {
        method: 'POST',
        body: JSON.stringify({
          query: text,
          session_id: sessionId,
          user_id: 'admin',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const botMsg = {
          id: Date.now() + 1,
          sender: 'bot',
          text: data.response || 'No response generated.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, botMsg]);
      } else {
        const err = await res.json().catch(() => ({}));
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now() + 1,
            sender: 'bot',
            text: err.detail || 'Failed to process request.',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isError: true,
          },
        ]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now() + 1,
          sender: 'bot',
          text: `Connection error: ${err.message}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isError: true,
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleResetSession = () => {
    const resetMsg = [
      {
        id: Date.now(),
        sender: 'bot',
        text: 'Session reset. What would you like to do?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
    setMessages(resetMsg);
    localStorage.setItem('chat_messages', JSON.stringify(resetMsg));
    const newSession = 'sess_' + Math.random().toString(36).substring(2, 9);
    setSessionId(newSession);
    localStorage.setItem('chat_session_id', newSession);
  };

  const quickPrompts = [
    'count users',
    'get user 1',
    'create user Sarah Connor, email sarah@skynet.com, phone +15550192837, address Los Angeles',
    'help',
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-[#0a0a0a] flex flex-col p-3 sm:p-6 max-w-5xl mx-auto">
      {/* Chat Window Container */}
      <div className="flex-1 bg-[#121212] border border-teal-900/40 rounded-2xl flex flex-col overflow-hidden shadow-2xl shadow-black">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900/80 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-500 to-emerald-400 p-0.5 flex items-center justify-center">
              <div className="w-full h-full bg-[#0a0a0a] rounded-[10px] flex items-center justify-center">
                <Bot className="w-5 h-5 text-teal-400" />
              </div>
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center space-x-2">
                <span>Gemini Assistant</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </h2>
              <p className="text-xs text-slate-400">Natural language database controller</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleResetSession}
              className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-all text-xs flex items-center space-x-1 cursor-pointer"
              title="Reset Chat"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset Session</span>
            </button>
          </div>
        </div>

        {/* Message Area */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start space-x-3 ${
                msg.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}
            >
              {/* Avatar */}
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-tr from-teal-600 to-emerald-500 text-slate-950'
                    : 'bg-slate-800 border border-teal-500/30 text-teal-400'
                }`}
              >
                {msg.sender === 'user' ? (
                  <User className="w-5 h-5" />
                ) : (
                  <Bot className="w-5 h-5" />
                )}
              </div>

              {/* Bubble */}
              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-teal-600 to-teal-700 text-white shadow-lg shadow-teal-600/10 rounded-tr-none'
                    : msg.isError
                    ? 'bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded-tl-none'
                    : 'bg-slate-900/90 border border-slate-800/90 text-slate-200 shadow-md rounded-tl-none'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>
                <div
                  className={`text-[10px] mt-1.5 font-mono ${
                    msg.sender === 'user' ? 'text-teal-200/70 text-right' : 'text-slate-500'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-start space-x-3">
              <div className="w-9 h-9 rounded-xl bg-slate-800 border border-teal-500/30 text-teal-400 flex items-center justify-center flex-shrink-0">
                <Bot className="w-5 h-5 animate-pulse" />
              </div>
              <div className="bg-slate-900/90 border border-slate-800/90 rounded-2xl rounded-tl-none p-4 flex items-center space-x-1.5">
                <div className="w-2 h-2 rounded-full bg-teal-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 rounded-full bg-teal-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 rounded-full bg-teal-400 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Prompts Bar */}
        <div className="px-4 py-2 bg-slate-900/40 border-t border-slate-800/60 overflow-x-auto flex items-center space-x-2 text-xs">
          <span className="text-slate-500 flex items-center space-x-1 flex-shrink-0">
            <Command className="w-3 h-3" />
            <span>Suggestions:</span>
          </span>
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              className="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-teal-500/20 text-slate-300 hover:text-teal-300 border border-slate-700/60 hover:border-teal-500/40 whitespace-nowrap transition-all cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Controls */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-4 bg-slate-900/80 border-t border-slate-800/80 flex items-center space-x-3"
        >
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder="Ask something... (e.g. 'count users', 'create user Sarah...')"
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-all"
          />

          <button
            type="submit"
            disabled={!inputQuery.trim() || isTyping}
            className="px-5 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-bold text-sm shadow-lg shadow-teal-500/20 flex items-center space-x-1.5 transition-all cursor-pointer disabled:opacity-40"
          >
            <span>Send</span>
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatPage;
