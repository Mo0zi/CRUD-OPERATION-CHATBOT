# Project Flow & Architecture Specification

This document details the complete end-to-end execution flow, sequence diagrams, and component interactions of the **User Management AI Chatbot** application.

---

## 🔁 1. Complete End-to-End Sequence Flow

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant Frontend as React 19 App (Port 5173)
    participant Proxy as Vite Proxy (/api)
    participant FastAPI as FastAPI Backend (Port 8001)
    participant Gemini as Google Gemini API
    participant SQLite as SQLite Database (user_management.db)

    %% Authentication Flow
    rect rgb(15, 23, 42)
    note right of User: 1. Authentication Flow
    User->>Frontend: Enter credentials (admin@example.com / password)
    Frontend->>Proxy: POST /api/login
    Proxy->>FastAPI: Forward to http://127.0.0.1:8001/api/login
    FastAPI->>FastAPI: Validate against static/admin hash
    FastAPI-->>Frontend: Return JWT Access Token
    Frontend->>Frontend: Store Token & Email in AuthContext / localStorage
    Frontend-->>User: Redirect to /dashboard
    end

    %% Dashboard Flow
    rect rgb(15, 23, 42)
    note right of User: 2. Dashboard User List Flow
    User->>Frontend: Navigate to /dashboard
    Frontend->>Proxy: GET /api/users (Header: Authorization Bearer JWT)
    Proxy->>FastAPI: Forward GET /api/users
    FastAPI->>SQLite: SELECT * FROM users ORDER BY id DESC
    SQLite-->>FastAPI: Return User Records
    FastAPI-->>Frontend: Return JSON Array of Users
    Frontend-->>User: Render Users Table & Statistics Summary
    end

    %% Chatbot Query Flow
    rect rgb(15, 23, 42)
    note right of User: 3. Natural Language Chat Flow
    User->>Frontend: Type query (e.g., "afaq ko add kr do" / "count users")
    Frontend->>Proxy: POST /api/chat (query, session_id, user_id)
    Proxy->>FastAPI: Forward POST /api/chat
    FastAPI->>FastAPI: Check Conversation Session State

    alt Gemini API Call
        FastAPI->>Gemini: Call Gemini model with System Prompt + Query
        Gemini-->>FastAPI: Return Structured JSON { intent, fields, message }
    else Gemini Offline / API Error Fallback
        FastAPI->>FastAPI: Execute Rule-Based Intent Parser (English & Roman Urdu)
    end

    FastAPI->>FastAPI: Validate Intent & Required Fields (name, email, phone)

    alt Missing Required Parameters
        FastAPI-->>Frontend: Return Conversational Clarifying Question
    else Valid Intent & Complete Parameters
        FastAPI->>SQLite: Perform Action (INSERT/SELECT/UPDATE/DELETE)
        SQLite-->>FastAPI: Action Success / ID Created
        FastAPI-->>Frontend: Return Conversational Confirmation
    end

    Frontend->>Frontend: Save Message & Session ID to LocalStorage
    Frontend-->>User: Render Bot Response Bubble in Chat Timeline
    end
```

---

## 🧱 2. Subsystem & Component Flow Details

### A. Authentication & Route Protection Layer
- **Component:** `frontend/src/context/AuthContext.jsx` & `frontend/src/components/ProtectedRoute.jsx`
- **Logic:**
  1. On application boot, `AuthContext` reads the existing `token` from `localStorage`.
  2. The `authFetch` wrapper automatically injects the `Authorization: Bearer <token>` header into all outbound API requests.
  3. `ProtectedRoute` checks `isAuthenticated`. If false, automatically redirects navigation to `/login`.
  4. On logout, clears JWT token, user email, and chat session state from `localStorage`.

---

### B. Chatbot Intent Processing Pipeline
- **Component:** `app/services/chat_service.py`
- **Pipeline Steps:**
  1. **Session Initialization:** `conversation.init_session(session_id, user_id)` creates an active session state if not already initialized.
  2. **LLM Structured Inference:** Sends query along with `SYSTEM_PROMPT` to Gemini (`llm.call_gemini`).
  3. **JSON Extraction:** `_parse_llm_response()` cleans markdown code blocks (` ```json ... ``` `) and parses JSON into `intent` and `fields`.
  4. **Fallback Parser:** If Gemini is unreachable or unconfigured, `_rule_based_intent_parser()` processes the query using regex rules supporting English and Roman Urdu keywords (`banao`, `add kr do`, `delete`, `count`).
  5. **Parameter Validation:** For `CREATE` intents, verifies that `name`, `email`, and `phone` are present. If missing, formats a conversational question in the user's language asking for missing inputs.
  6. **Execution:** Calls `user_service` to execute the database query against SQLite.
  7. **Exception Safety:** Top-level `try...except` block in `handle_chat()` traps any runtime error and returns a friendly user message.

---

### C. Persistent Chat Interface
- **Component:** `frontend/src/pages/ChatPage.jsx`
- **Persistence Architecture:**
  - `messages` state is initialized from `localStorage.getItem('chat_messages')`.
  - `sessionId` state is initialized from `localStorage.getItem('chat_session_id')`.
  - Every message added triggers a `useEffect` hook syncing the updated message array to `localStorage`.
  - Navigating between `/dashboard` and `/chat` unmounts and remounts components without losing any chat history.
  - "Reset Session" button resets messages back to the default greeting and generates a fresh `session_id`.

---

### D. User Service & Database Layer
- **Component:** `app/services/user_service.py` & `data/user_management.db`
- **Database Engine:** SQLite 3
- **Functions:**
  - `get_all_users()`: Returns list of dictionaries for all users.
  - `create_user(user_data)`: Inserts new user record.
  - `get_user(user_id)`: Fetches single user record.
  - `update_user(user_id, update_data)`: Updates non-null fields for a user.
  - `delete_user(user_id)`: Removes user record.
  - `count_users()`: Performs `SELECT COUNT(*) FROM users`.
