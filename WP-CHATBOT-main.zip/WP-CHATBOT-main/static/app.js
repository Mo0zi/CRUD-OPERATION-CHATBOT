document.addEventListener("DOMContentLoaded", () => {
  const loginModal = document.getElementById("login-modal");
  const loginForm = document.getElementById("login-form");
  const emailInput = document.getElementById("email");
  const chatSection = document.getElementById("chat-section");
  const chatForm = document.getElementById("chat-form");
  const queryInput = document.getElementById("query");
  const messagesDiv = document.getElementById("messages");

  // Session ID for chat
  const sessionId = "session_" + Math.random().toString(36).substring(2, 9);

  function getAuthToken() {
    return localStorage.getItem("authToken");
  }

  function setAuthToken(token) {
    localStorage.setItem("authToken", token);
  }

  function showLogin() {
    loginModal.classList.remove("hidden");
    chatSection.classList.add("hidden");
  }

  function showChat() {
    loginModal.classList.add("hidden");
    chatSection.classList.remove("hidden");
  }

  // Check initial state
  const token = getAuthToken();
  if (token) {
    showChat();
  } else {
    showLogin();
  }

  // Handle Login Submit
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = emailInput.value.trim();
    if (!email) return;

    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email, password: "password123" }),
      });

      if (!res.ok) {
        alert("Login failed. Please try again.");
        return;
      }

      const data = await res.json();
      if (data.access_token) {
        setAuthToken(data.access_token);
        showChat();
        appendMessage("bot", "Welcome! You can ask me to create, read, update, delete, search, or count users.");
      }
    } catch (err) {
      console.error("Login error:", err);
      alert("Error logging in: " + err.message);
    }
  });

  function appendMessage(sender, text) {
    const msgDiv = document.createElement("div");
    msgDiv.classList.add("message", sender);
    msgDiv.textContent = text;
    messagesDiv.appendChild(msgDiv);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  }

  // Handle Chat Form Submit (Send click or Enter)
  chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = queryInput.value.trim();
    if (!text) return;

    appendMessage("user", text);
    queryInput.value = "";

    let currentToken = getAuthToken();
    if (!currentToken) {
      // Auto login as admin if token is missing
      try {
        const loginRes = await fetch("/api/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: "admin@example.com", password: "password123" }),
        });
        const loginData = await loginRes.json();
        if (loginData.access_token) {
          currentToken = loginData.access_token;
          setAuthToken(currentToken);
        }
      } catch (err) {
        console.error("Auto login failed:", err);
      }
    }

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + currentToken,
        },
        body: JSON.stringify({
          query: text,
          session_id: sessionId,
          user_id: "admin",
        }),
      });

      if (res.status === 401) {
        // Token expired/invalid, clear token and show login
        localStorage.removeItem("authToken");
        showLogin();
        appendMessage("bot", "Session expired. Please log in again.");
        return;
      }

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        appendMessage("bot", "Error: " + (errorData.detail || "Server error occurred."));
        return;
      }

      const data = await res.json();
      appendMessage("bot", data.response || "No response received.");
    } catch (err) {
      console.error("Chat error:", err);
      appendMessage("bot", "Connection error: " + err.message);
    }
  });
});
