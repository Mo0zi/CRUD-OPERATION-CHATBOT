# 📘 Product Overview & Architecture Document

This document provides a comprehensive explanation of the **User Management AI Chatbot** application architecture, folder structure, request lifecycles, and component mechanisms.

---

## 1. 🌟 Overall Project Summary

The **User Management AI Chatbot** is an administrative portal allowing administrators to manage user accounts (Create, Read, Update, Delete, Count) through two primary interfaces:
1. **Interactive System Dashboard**: A modern visual data table for managing users with single-click actions (Edit via modal, Delete via confirmation dialog) and a modal user creation form.
2. **Bilingual AI Chatbot Assistant**: An intelligent conversational agent that understands natural language in **both English and Roman Urdu**, maintains multi-turn session memory, handles flexible lookups (by ID, email, or name with fuzzy matching), and collects user fields step-by-step before performing database operations.

---

## 2. 📂 Project Folder & File Structure

### 🔌 Backend (FastAPI - Python)
- `app/main.py`: Entry point for the FastAPI server. Configures CORS middleware, initializes vector store state on startup, mounts API routes, and serves static/production React frontend assets.
- `app/config.py`: Contains global configuration parameters including database file locations, JWT secrets, algorithm definitions, and Gemini API keys.
- `app/models.py`: Defines Pydantic blueprints and schemas for request/response validation (`AdminLoginRequest`, `AdminLoginResponse`, `UserCreate`, `UserUpdate`, `UserResponse`, `ChatRequest`, `ChatResponse`).
- `app/routes.py`: Defines REST API endpoints (`/api/login`, `/api/users`, `/api/chat`) protected by JWT authentication dependencies.
- `schema.sql`: Database schema definition for the `users` table (`id`, `name`, `email`, `phone`, `address`, `created_at`, `updated_at`).
- `app/db.py`: Executes low-level SQLite queries (`INSERT`, `SELECT`, `UPDATE`, `DELETE`), handles dynamic schema migrations, and performs **fuzzy name matching** (typo tolerance) and exact email lookups.

### 🧠 Services & Business Logic
- `app/services/auth.py`: Provides JWT access token creation and token verification (`get_current_admin`) for authentication headers.
- `app/services/user_service.py`: Business logic layer acting as a middleware between API endpoints and database helper modules, performing validations (e.g. duplicate email checks).
- `app/services/chat_service.py`: **Core Chatbot Controller.** Manages multi-turn conversation memory, constructs structured contextual prompts for Google Gemini AI, handles regex/rule-based fallbacks, parses intents (CREATE, READ, UPDATE, DELETE, COUNT, HELP), and executes database actions when required parameters are gathered.

### 🤖 AI & RAG Subsystem
- `app/chatbot/llm.py`: Communications wrapper for Google's **Gemini AI API** (`gemini-flash-lite-latest`).
- `app/chatbot/conversation.py`: Thread-safe session state store (`session_id`) tracking collected parameters, active intents, target identities, and pending user details across conversational turns.
- `app/chatbot/rag/embeddings.py`: Generates numerical vector embeddings for text using `SentenceTransformer` (`all-MiniLM-L6-v2`).
- `app/chatbot/rag/vector_store.py`: Wraps a local **FAISS vector index** (`store.pkl`) for similarity searches.
- `app/chatbot/rag/retriever.py`: High-level utility to query top-k similar entries from the FAISS vector index (preserved for future semantic search extensions).

### 💻 Frontend (React 19 + Vite + Tailwind CSS)
- `frontend/src/App.jsx`: Main React application container configuring page routing (`/login`, `/dashboard`, `/chat`) and protected navigation.
- `frontend/src/context/AuthContext.jsx`: Provides JWT token management, persistent `localStorage` authorization, email-only auto-login, and a custom `authFetch` utility.
- `frontend/src/components/Navbar.jsx`: Navigation bar with brand identifier, page links, user profile display, and logout trigger.
- `frontend/src/components/ProtectedRoute.jsx`: Authentication guard preventing unauthenticated access to protected routes.
- `frontend/src/pages/LoginPage.jsx`: Dark-themed administrator login interface supporting email-only auto-login.
- `frontend/src/pages/DashboardPage.jsx`: Interactive user management dashboard displaying registered users (`Name`, `Email`, `Phone`, `Address`) with search filtering, user creation modal, inline Edit modal, and Delete confirmation.
- `frontend/src/pages/ChatPage.jsx`: AI Chat interface with real-time turn rendering, session reset option, quick prompt suggestions, and auto-scrolling message log.

---

## 3. 🔄 Step-by-Step Request Flow

When an administrator types `"create user Bilal"` into the Chat UI:

```
[Chat UI (React)]
       │
       ▼ (1) POST /api/chat { query: "create user Bilal", session_id: "xyz" }
[API Route (routes.py)]
       │
       ▼ (2) Verify JWT Token via auth.py
[Chat Service (chat_service.py)]
       │
       ▼ (3) Retrieve existing session memory from conversation.py
[Google Gemini AI (llm.py)]
       │
       ▼ (4) Intent parsed: "CREATE", extracted fields: { name: "Bilal" }
[Session Memory (conversation.py)]
       │
       ▼ (5) Merged pending data: { name: "Bilal" }, missing: ["email", "phone", "address"]
[Chat UI (React)]
       ▲
       └─ (6) Prompt response: "To add 'Bilal', please provide their email, phone, address."
```

Once all required fields (`name`, `email`, `phone`, `address`) are provided across turns:
1. `chat_service.py` calls `user_service.create_user()`.
2. `db.py` executes an `INSERT` query into `user_management.db`.
3. `conversation.py` resets the session state.
4. Chatbot confirms creation: `"User Bilal has been created successfully with ID 12."`

---

## 4. 🔍 User Lookup & Search Architecture

- **Lookup Priority:**
  1. **By ID:** If query contains a numeric ID (`"get user 1"`), exact integer ID lookup is performed.
  2. **By Email:** If target contains `@` (`"john@example.com"`), exact email match is executed.
  3. **By Name:** Search performs string normalization and `difflib.SequenceMatcher` fuzzy matching to support partial names and typo-tolerant queries (`"samantha"` -> `"Samantha Reed"`).
- **Language Support:** Prompts and regex fallback handlers support English and **Roman Urdu** (`"ali ka record dekhao"`, `"afaq ki details dikhao"`, `"who is afaq"`).

---

## 5. 🗄️ Database Architecture

- **Engine:** SQLite 3
- **Primary File Path:** `data/user_management.db`
- **Table Schema (`users`):**
  - `id`: `INTEGER PRIMARY KEY AUTOINCREMENT`
  - `name`: `TEXT NOT NULL`
  - `email`: `TEXT NOT NULL UNIQUE`
  - `phone`: `TEXT NOT NULL`
  - `address`: `TEXT NOT NULL`
  - `created_at`: `TIMESTAMP DEFAULT CURRENT_TIMESTAMP`
  - `updated_at`: `TIMESTAMP DEFAULT CURRENT_TIMESTAMP`

---

## 6. 🔐 Authentication Mechanism

1. User enters their email on `LoginPage.jsx`.
2. `/api/login` verifies if the email is a pre-authorized system admin (`admin@example.com`, `chatbot@gmail.com`) or exists in the `users` table.
3. `/api/login` endpoint calls `auth.create_access_token(email)` to issue a signed **JSON Web Token (JWT)**.
4. React app saves the token in `localStorage.setItem('token', access_token)`.
5. `AuthContext` attaches `Authorization: Bearer <token>` header to all backend requests.
6. FastAPI dependency `get_current_admin` validates token signatures before authorizing operations.

---

## 7. 🌐 Frontend-Backend Integration

- **Development:** Vite dev server proxies `/api` calls to `http://127.0.0.1:8001`.
- **Production / Railway:** FastAPI serves built frontend static assets from `frontend_dist/` and handles client-side routing fallback via single-page application routing.
